package decoratorPattern;

public interface PizzaComponentDecorator extends PizzaComponent{
	public PizzaComponent getPizzaComponent();
}