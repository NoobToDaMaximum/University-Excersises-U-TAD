package decoratorPattern;

public abstract class PizzaToppings extends Pizza{
	public abstract String getDesc();
}
